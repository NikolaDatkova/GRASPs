package GRASP03;

import java.util.Scanner;

public class MyScanner {
    Scanner myScanner = new Scanner(System.in);

    // scan integers
    public int scanInts() {
        int inputInt = myScanner.nextInt();
        return inputInt;
    }

    public void close() {
        myScanner.close();
    }
}
