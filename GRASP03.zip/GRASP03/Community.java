package GRASP03;

import java.util.ArrayList;

public class Community {
    ArrayList<Reader> readerCommunity;

    Community() {
        readerCommunity = new ArrayList<>();
    }

    // accessors
    public int numberOfReaders() {
        return readerCommunity.size();
    }

    public Reader getReader(int index) {
        return readerCommunity.get(index);
    }

    public String getReaderID(Reader reader) {
        int readerIndex = readerCommunity.indexOf(reader);
        String readerID = String.format ("%05d", readerIndex);
        return readerID;
    }

    // mutators
    public void addMember(Reader newReader) {
        readerCommunity.add(newReader);
    }
}
