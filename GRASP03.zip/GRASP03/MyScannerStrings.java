package GRASP03;

import java.util.Scanner;

public class MyScannerStrings {
    Scanner myScannerString = new Scanner(System.in);

    // scan strings
    public String scanString() {
        String inputString = myScannerString.nextLine();
        return inputString;
    }

    public void close() {
        myScannerString.close();
    }
}
