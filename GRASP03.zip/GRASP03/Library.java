package GRASP03;

import java.time.LocalDate;

public class Library {
      public static void main(String[] args) {
            // general definitions
            MyScanner myScanner = new MyScanner();
            MyScannerStrings myScannerStrings = new MyScannerStrings();
            int userChoice;
            int i;

            // default book offer
            Shelf bookShelf = new Shelf();
            bookShelf.addBook(new Book("B1"));
            bookShelf.addBook(new Book("B2"));
            bookShelf.addBook(new Book("B3"));
            bookShelf.addBook(new Book("B4"));
            bookShelf.addBook(new Book("B5"));

            // default reader community
            Community readerCommunity = new Community();
            readerCommunity.addMember(new Reader("R1", "r1@gmail.com"));
            readerCommunity.addMember(new Reader("R2", "r2@gmail.com"));
            readerCommunity.addMember(new Reader("R3", "r3@gmail.com"));
            readerCommunity.addMember(new Reader("R4", "r3@gmail.com"));

            // welcome
            System.out.println("Welcome to the library!");
            System.out.println("");

            // offer of books
            System.out.println("This library has many books: ");
            for (i = 0; i < bookShelf.numberOfBooks(); i++) {
                  System.out.println(bookShelf.getBook(i).bookTitle);
            }
            System.out.println("");

            // community introduction
            System.out.println("This library has also a large community of readers! Here are our members: ");
            for (i = 0; i < readerCommunity.numberOfReaders();i++){
                  System.out.println(readerCommunity.getReader(i).readerName);
            }
            System.out.println("");

            System.out.println("Now it's your turn! How can we help?");
            System.out.println("1.   (ONLY FOR REGISTERRED READERS) I came to borrow a book.");
            System.out.println("2.   (ONLY FOR REGISTERRED READERS) I came to return a book.");
            System.out.println("3.   (REGISTER HERE) I came to register as a new reader.");
            System.out.println("4.   (UNRESTRICTED) I came to donate a book.");
            System.out.println("5.   (ONLY FOR REGISTERRED READERS) I came to check out my reader status.");
            System.out.println("6.   Exit");

            System.out.println("Enter your choice (1-6):");
            userChoice = myScanner.scanInts();

            // menu choices
            while (userChoice != 6) {

                  // advanced menu
                  switch (userChoice) {
                        case 1:
                              // show a list of books
                              System.out.println("These are the books offered:");
                              for (i = 0; i < bookShelf.numberOfBooks(); i++) {
                                    System.out.printf("Book #%d is '%s'%n", i, bookShelf.getBook(i).bookTitle);
                              }

                              // ask for book choice
                              int bookChoice;
                              System.out.println(
                                          "Which of the books would you like to borrow? (Enter the book number)");
                              bookChoice = myScanner.scanInts();
                              Book bookToBorrow = bookShelf.getBook(bookChoice);

                              // ask for identity
                              System.out.println("What is your name?");
                              String borrowerName = myScannerStrings.scanString();
                              Reader borrower;

                              // identify in reader community
                              for (i = 0; i < readerCommunity.numberOfReaders(); i++) {
                                    if (borrowerName.equals(readerCommunity.getReader(i).readerName)) {
                                          borrower = readerCommunity.getReader(i);
                                          // check if the book is borrowed
                                          if (bookToBorrow.checkIfBorrowed() == false) {
                                                // lend if not
                                                bookToBorrow.borrowBook(bookToBorrow, borrower);
                                                System.out.println("Have fun reading " + bookToBorrow.getBookTitle()
                                                            + "! You need to bring the book back by "
                                                            + bookToBorrow.bookDateExpected + ".");
                                          } else if (bookToBorrow.checkIfBorrowed() == true) {
                                                // apologise if yes
                                                System.out.println(
                                                            "Apologies! This book is currently lent out. We expect it to be returned on "
                                                                        + bookToBorrow.bookDateExpected + ".");
                                          }
                                    }
                              }
                              break;
                        case 2:
                              // list of books
                              System.out.println("These are the books offered:");
                              for (i = 0; i < bookShelf.numberOfBooks(); i++) {
                                    System.out.printf("Book #%d is '%s'%n", i, bookShelf.getBook(i).bookTitle);
                              }

                              // identify book
                              System.out.println(
                                          "Which of the books would you like to return? (Enter the book number)");
                              bookChoice = myScanner.scanInts();
                              Book bookToReturn = bookShelf.getBook(bookChoice);

                              // check for fines
                              LocalDate today = LocalDate.now();
                              LocalDate bookDateExpected = bookToReturn.getDateExpected();
                              bookToReturn.checkFines(today, bookDateExpected);

                              // identify reader
                              System.out.println("What is your name?");
                              String returnerName = myScannerStrings.scanString();
                              Reader returner;

                              // identify in reader community
                              for (i = 0; i < readerCommunity.numberOfReaders(); i++) {
                                    if (returnerName.equals(readerCommunity.getReader(i).readerName)) {
                                          returner = readerCommunity.getReader(i);
                                          // return book
                                          bookToReturn.returnBook(bookToReturn, returner);
                                          System.out.println("Thank you for returning " + bookToReturn.bookTitle + "!");
                                    }
                              }
                              break;
                        case 3:
                              // ask for name
                              System.out.println("Enter your name: ");
                              String newReaderName = myScannerStrings.scanString();

                              // ask for email
                              System.out.println("Enter your email address: ");
                              String newReaderEmail = myScannerStrings.scanString();

                              // add to the community
                              Reader newReader = new Reader(newReaderName, newReaderEmail);
                              readerCommunity.addMember(newReader);
                              break;
                        case 4:
                              // ask for book name
                              System.out.println("What is the name of the book you wish to donate?");
                              String newBookName = myScannerStrings.scanString();

                              // add the book to the shelf
                              Book newBook = new Book(newBookName);
                              bookShelf.addBook(newBook);

                              System.out.println("Thank you for donating " + newBookName + " to the library!");
                              break;
                        case 5:
                              // identify reader
                              System.out.println("What is your name?");
                              String readerName = myScannerStrings.scanString();
                              Reader reader;

                              // identify in reader community
                              for (i = 0; i < readerCommunity.numberOfReaders(); i++) {
                                    if (readerName.equals(readerCommunity.getReader(i).readerName)) {
                                          reader = readerCommunity.getReader(i);
                                          System.out.print("Your reader ID is: ");
                                          System.out.println(readerCommunity.getReaderID(reader));
                                          System.out.println("Your email address is: " + reader.readerEmail);
                                          System.out.println("Book you have borrowed: ");
                                          reader.getTitlesBorrowed();
                                    }
                              }
                              break;
                        default:
                              System.out.println("Invalid input");
                              break;

                  }
                  System.out.println("How else can we help?");
                  System.out.println("1.   (ONLY FOR REGISTERRED READERS) I came to borrow a book.");
                  System.out.println("2.   (ONLY FOR REGISTERRED READERS) I came to return a book.");
                  System.out.println("3.   (REGISTER HERE) I came to register as a new reader.");
                  System.out.println("4.   (UNRESTRICTED) I came to donate a book.");
                  System.out.println("5.   (ONLY FOR REGISTERRED READERS) I came to check out my reader status.");
                  System.out.println("6.   Exit");

                  System.out.println("Enter your choice (1-6):");
                  userChoice = myScanner.scanInts();

            }
            System.out.println("Goodbye!");
      }
}
