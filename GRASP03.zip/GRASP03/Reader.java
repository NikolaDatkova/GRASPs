package GRASP03;

import java.util.ArrayList;

public class Reader {
    
    String readerName;
    String readerEmail;
    int readerID;
    ArrayList<Book> booksBorrowed;

    Reader(String readerName, String readerEmail)
    {
        this.readerName=readerName;
        this.readerEmail=readerEmail;
        this.booksBorrowed=new ArrayList<Book>();
    }

    // accessors
    public String getReaderName()
    {
        return readerName;
    }

    public String getReaderEmail()
    {
        return readerEmail;
    }

    public void getTitlesBorrowed()
    {
        int i;
        for(i=0;i<booksBorrowed.size();i++)
            System.out.println(booksBorrowed.get(i).bookTitle);
    }

    // mutators
    public void takeBook(Book bookToBorrow)
    {
        booksBorrowed.add(bookToBorrow);
    }

    public void handInBook(Book bookToBorrow)
    {
        booksBorrowed.remove(bookToBorrow);
    }
}
