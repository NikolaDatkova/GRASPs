package GRASP03;

import java.time.LocalDate;

public class Book {

    String bookTitle;
    int bookID;
    boolean bookBorrowed;
    LocalDate bookDateExpected;

    Book(String bookTitle) {
        this.bookTitle = bookTitle;
        bookID = 1;
        bookBorrowed = false;
    }

    // accessors
    public String getBookTitle() {
        return bookTitle;
    }

    public int getBookID() {
        return bookID;
    }

    public LocalDate getDateExpected() {
        return bookDateExpected;
    }

    public boolean checkIfBorrowed() {
        return bookBorrowed;
    }

    // mutators
    public void borrowBook(Book bookToBorrow, Reader borrower) {
        bookBorrowed = true;
        bookDateExpected = LocalDate.now().plusMonths(1);
        borrower.takeBook(bookToBorrow);
    }

    public void returnBook(Book bookToBorrow, Reader borrower) {
        bookBorrowed = false;
        bookDateExpected = null;
        borrower.handInBook(bookToBorrow);
    }

    public void checkFines(LocalDate today, LocalDate bookDateExpected)
    {
        if (today.isAfter(bookDateExpected))
        {
            System.out.println("Sorry, you also need to pay a fine for late return.");
        }
    }

}
