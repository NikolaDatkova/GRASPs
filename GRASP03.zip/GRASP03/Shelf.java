package GRASP03;

import java.util.ArrayList;

public class Shelf {
    ArrayList<Book> bookShelf;

    Shelf() {
        bookShelf = new ArrayList<>();
    }

    public void addBook(Book book) {
        bookShelf.add(book);
    }

    public int numberOfBooks() {
        return bookShelf.size();
    }

    public Book getBook(int index) {
        return bookShelf.get(index);
    }
}
